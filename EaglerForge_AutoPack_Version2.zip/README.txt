EaglerForge Automation Pack Version 2 (Template)

This pack contains 50+ JavaScript modules.
These are STRUCTURAL TEMPLATES ONLY.

Features included:
- Storage network system
- Item/fluid/energy pipes
- Automation machines
- Power generation system
- Utility blocks

NOTE:
This is NOT a port of any Forge mod.
All systems must be implemented using EaglerForge API manually.
